const arr = ["a", "b"];
const str = "hello world";

module.exports = { arr, str };
