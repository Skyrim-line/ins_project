const value = require("./test2");
const { arr, str } = require("./test3");
const { output } = require("./test4");
let text = "hello node";
console.log(text);
console.log(value);
console.log(arr, " ", str);
console.log("output", output);
