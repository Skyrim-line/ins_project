const fruits = ["apple", "kiwi"];
const animals = ["cat", "dog"];
global.myFruits = fruits;
global.myAnimals = animals;
console.log(global);
