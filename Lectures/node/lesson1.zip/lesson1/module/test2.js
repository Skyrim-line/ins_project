require("./test5");

let text = "We are learning node.js";
console.log("myFruits", global.myFruits);
console.log(global.myAnimals);
module.exports = text;
