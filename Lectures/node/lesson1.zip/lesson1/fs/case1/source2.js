console.log("hello node");
function sum(a, b) {
  return a + b;
}

const result = sum(1, 3);
console.log("result", result);
